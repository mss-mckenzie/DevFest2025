print("Hello World!")
print("Welcome Freenove!")
