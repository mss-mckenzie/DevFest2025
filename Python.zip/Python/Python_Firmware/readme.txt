Please flash different firmware for different Pico development boards.
Pico: RPI_PICO-20240602-v1.23.0.uf2
Pico W: RPI_PICO_W-20240602-v1.23.0.uf2
Pico 2: RPI_PICO2-20241129-v1.24.1.uf2(Cortex-M33)
		RPI_PICO2-RISCV-20240809-v1.24.0.uf2(RISC-V)
Pico 2W: RPI_PICO2_W-20241129.uf2